<?php
define ('PAGELIMIT','20');
define ("TITLE","Pharma Health");
define ("SITE_NAME","Pharma Health");


define ("DB_HOST","localhost");
define ("DB_NAME", "pharmahealth-2024");
define ("DB_USER", "root");
define ("DB_PASS","");


?>