<?php
$params = array(
	"testmode"   => "on",
	"private_live_key" => "sk_live_KrFqYNYsFgPkuZrlGMKyEWox",
	"public_live_key"  => "pk_live_9hbZiClvX07Op14SA6MTeQJn",
	"private_test_key" => "sk_test_51Nn3SfFai0RMyBsIk1fmupsx9p7KtELDIqXTJo6iAvdMDqvPanLjr38EjgZnLOT1q1IWZrZQvot7hmYHaQXofWrr00EhABMcEq",
	"public_test_key"  => "pk_test_51Nn3SfFai0RMyBsIlJqJTFgQc8cBo1Sx62bHrUUIxHof6rfhwYDwm2mrpg8ZBoBFbH9r9gG8HYeZU600Q5SP8HVY00y5p3kVcs"
);

?>