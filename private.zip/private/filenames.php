<?php
// -----------------------       F O L D E R   N A M E S         -----------------

define("FOLDER_ADMIN","admin/");
define("PATIENT_ADMIN","patient/account/");


define("PRESCRIBER_ADMIN","clinician/account/");

define("PHARMACY_ADMIN","pharmacy/account/");

define ("ENCRYPTION_KEY","ALDpb2039a@klazkad9020mnjjaddfgjhaacggwq");


?>
